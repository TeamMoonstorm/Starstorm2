# R2API.Loadout - Registering skills, skins and entity states

## About

R2API.Loadout is a legacy submodule for R2API

For adding new SkillDefs, SkillFamilies and EntityStates, use the ContentAddition class found in the R2API.ContentManagement module

For the skins features, they'll eventually be moved to a Skin submodule.

## Changelog

### '1.0.2'
* Add missing `BepInDependency` to `R2API.ContentManagement` and `R2API.Skins`

### '1.0.0'
* Split from the main R2API.dll into its own submodule.
