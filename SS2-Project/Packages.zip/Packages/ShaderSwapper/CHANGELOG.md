## 1.0.1
* Fix shader swapping resetting the render queue of materials (thanks Bog)
* Update async coroutines to always yield null instead of yielding the load handles directly

## 1.0.0
* First release