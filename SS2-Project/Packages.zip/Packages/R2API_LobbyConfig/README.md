# R2API.LobbyConfig - Modifying the in-game lobby rules.

## About

R2API.LobbyConfig is a submodule for R2API that allows mod creators to modify the in-game lobby rules.

## Changelog

### '1.0.1'
* Fix the NuGet package which had a dependency on a non-existent version of `R2API.Core`.

### '1.0.0'
* Split from the main R2API.dll into its own submodule.
